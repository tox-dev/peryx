VALUE = "veloxdemo"
